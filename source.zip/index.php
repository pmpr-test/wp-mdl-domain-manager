<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517673e6e1             |
    |_______________________________________|
*/
 use Pmpr\Module\DomainManager\DomainManager; DomainManager::symcgieuakksimmu();
