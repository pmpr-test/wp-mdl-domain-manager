<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec6b5533a             |
    |_______________________________________|
*/
 use Pmpr\Module\DomainManager\DomainManager; DomainManager::symcgieuakksimmu();
