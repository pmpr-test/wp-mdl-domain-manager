<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b04b9e186             |
    |_______________________________________|
*/
 namespace Pmpr\Module\DomainManager\Model; use Pmpr\Module\DomainManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Domain::symcgieuakksimmu(); Ownership::symcgieuakksimmu(); } }
