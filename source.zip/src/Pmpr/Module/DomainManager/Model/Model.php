<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7950b3e3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\DomainManager\Model; use Pmpr\Module\DomainManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Domain::symcgieuakksimmu(); Ownership::symcgieuakksimmu(); } }
